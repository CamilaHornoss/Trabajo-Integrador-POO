import java.util.Calendar;

public class Prestamo {
   /** Fecha en la que se retira el libro en el prestamo. */
   private Calendar fechaRetiro;
   /** Fecha en la que se devuelve el libro, Inicialmente es null hasta que se registre la devolucion. */
   private Calendar fechaDevolucion;
   /** Socio que solicita el prestamo. */
   private Socio socio;
   /** Libro a ser prestado. */
   private Libro libro;

   /**
    * Constructor de la clase Prestamo. Inicializa un nuevo préstamo asignando
    * una fecha de retiro, un socio y un libro. La fecha de devolución se inicializa
    * como null, indicando que el libro aún no ha sido devuelto.
    *
    * @param p_fechaRetiro Fecha en la que se retira el libro.
    * @param p_socio Socio que realiza el préstamo.
    * @param p_libro Libro que es prestado.
   */
   public Prestamo(Calendar p_fechaRetiro, Socio p_socio, Libro p_libro) {
      this.setFechaRetiro(p_fechaRetiro);
      this.setSocio(p_socio);
      this.setLibro(p_libro);
      this.setFechaDevolucion((Calendar)null); // Indica que el libro aún no ha sido devuelto.
   }

   /**
   * Establece la fecha de retiro del préstamo.
   *
   * @param p_fecha Fecha en la que se retira el libro.
   */
   private void setFechaRetiro(Calendar p_fecha) {
      this.fechaRetiro = p_fecha;
   }

   /**
   * Establece la fecha de devolución del préstamo.
   *
   * @param p_fecha Fecha en la que se devuelve el libro.
   */
   private void setFechaDevolucion(Calendar p_fecha) {
      this.fechaDevolucion = p_fecha;
   }

   /**
   * Establece el socio que realiza el préstamo.
   *
   * @param p_socio Objeto Socio que realiza el préstamo.
   */
   private void setSocio(Socio p_socio) {
      this.socio = p_socio;
   }

   /**
   * Establece el libro asociado al préstamo.
   *
   * @param p_libro Objeto Libro que se presta.
   */
   private void setLibro(Libro p_libro) {
      this.libro = p_libro;
   }

   /**
   * Obtiene la fecha de retiro del libro en el préstamo.
   *
   * @return Fecha de retiro del libro.
   */
   public Calendar getFechaRetiro() {
      return this.fechaRetiro;
   }

   /**
   * Obtiene la fecha de devolución del libro en el préstamo.
   *
   * @return Fecha de devolución del libro.
   */
   public Calendar getFechaDevolucion() {
      return this.fechaDevolucion;
   }

   /**
   * Obtiene el socio asociado a este préstamo.
   *
   * @return Objeto Socio que realiza el préstamo.
   */
   public Socio getSocio() {
      return this.socio;
   }

   /**
   * Obtiene el libro asociado a este préstamo.
   *
   * @return Objeto Libro prestado.
   */
   public Libro getLibro() {
      return this.libro;
   }

   /**
   * Registra la fecha de devolución del libro.
   *
   * @param p_fecha Fecha en la que el libro es devuelto.
   */
   public void registrarFechaDevolucion(Calendar p_fecha) {
      this.fechaDevolucion = p_fecha;
   }

   /**
    * Verificamos si el prestamo se encuentra vencido. Para eso comparamos 
    * @param p_fecha
    * @return
    */
   public boolean vencido(Calendar p_fecha) {
      int diasPrestamo = this.getSocio().getDiasPrestamo();
      Calendar retiro = this.getFechaRetiro();
      retiro.add(5, diasPrestamo);
      return p_fecha.before(retiro) || p_fecha.equals(retiro);
   }

   public String toString(){
      return "Retiro: " + this.getFechaRetiro() + "-" + "Devolucion: " + this.getFechaDevolucion() + 
             "Libro: " + this.getLibro().toString() + 
             "Socio: " + this.getSocio().getNombre();
   }
}


 