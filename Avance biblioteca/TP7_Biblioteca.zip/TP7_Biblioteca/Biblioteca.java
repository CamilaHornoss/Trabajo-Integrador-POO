import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Biblioteca: administra los libros, los socios y los préstamos.
 */
public class Biblioteca {

    private String nombre;
    private ArrayList<Socio> socios;
    private ArrayList<Libro> libros;

    public Biblioteca(String p_nombre) {
        this.nombre = p_nombre;
        this.socios = new ArrayList<Socio>();
        this.libros = new ArrayList<Libro>();
    }

    public String getNombre() {
        return nombre;
    }

    // ------------------------------------------------------------------
    // Altas
    // ------------------------------------------------------------------

    public void nuevoLibro(String p_titulo, int p_edicion, String p_editorial, int p_anio) {
        libros.add(new Libro(p_titulo, p_edicion, p_editorial, p_anio));
    }

    public void nuevoSocioEstudiante(int p_dniSocio, String p_nombre, String p_carrera) {
        socios.add(new Estudiante(p_dniSocio, p_nombre, p_carrera));
    }

    public void nuevoSocioDocente(int p_dniSocio, String p_nombre, String p_area) {
        socios.add(new Docente(p_dniSocio, p_nombre, p_area));
    }

    // Único punto que depende de cómo se llama el método en Libro.
    // Con la clase Libro del diseño (la que hace tu compañero) es ultimoPrestamo().
    // El Libro de GT_4.jar lo llama getPrestamo().
    private Prestamo ultimoPrestamoDe(Libro p_libro) {
        return p_libro.getPrestamo();
    }

    // ------------------------------------------------------------------
    // Préstamos y devoluciones
    // ------------------------------------------------------------------

    /**
     * Crea el préstamo y lo agrega en el libro y en el socio.
     * Devuelve false si el socio no puede pedir o si el libro ya está prestado.
     */
    public boolean prestarLibro(Calendar p_fechaRetiro, Socio p_socio, Libro p_libro) {
        if (p_socio.puedePedir() && !p_libro.prestado()) {
            Prestamo prestamo = new Prestamo(p_fechaRetiro, p_socio, p_libro);
            p_libro.addPrestamo(prestamo);
            p_socio.addPrestamo(prestamo);
            return true;
        }
        return false;
    }

    /**
     * Asigna la fecha de devolución (fecha actual) al último préstamo del libro.
     * Si el libro no está prestado, lanza LibroNoPrestadoException.
     */
    public void devolverLibro(Libro p_libro) throws LibroNoPrestadoException {
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException("El libro " + p_libro.getTitulo()
                    + " no se puede devolver ya que se encuentra en la biblioteca");
        }
        ultimoPrestamoDe(p_libro).registrarFechaDevolucion(new GregorianCalendar());
    }

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------

    /**
     * Cantidad de socios del tipo indicado ("Docente" o "Estudiante").
     */
    public int cantidadDeSociosPorTipo(String p_objeto) {
        int cantidad = 0;
        for (Socio socio : socios) {
            if (socio.soyDeLaClase().equals(p_objeto)) {
                cantidad++;
            }
        }
        return cantidad;
    }

    /**
     * Préstamos vencidos al día de la fecha (libros prestados con plazo vencido).
     */
    public ArrayList<Prestamo> prestamosVencidos() {
        ArrayList<Prestamo> vencidos = new ArrayList<Prestamo>();
        Calendar hoy = new GregorianCalendar();
        for (Libro libro : libros) {
            if (libro.prestado()) {
                Prestamo prestamo = ultimoPrestamoDe(libro);
                if (prestamo.vencido(hoy)) {
                    vencidos.add(prestamo);
                }
            }
        }
        return vencidos;
    }

    /**
     * Docentes que nunca tuvieron ni tienen un préstamo vencido.
     */
    public ArrayList<Docente> docentesResponsables() {
        ArrayList<Docente> responsables = new ArrayList<Docente>();
        for (Socio socio : socios) {
            if (socio instanceof Docente) {
                Docente docente = (Docente) socio;
                if (docente.esResponsable()) {
                    responsables.add(docente);
                }
            }
        }
        return responsables;
    }

    /**
     * Nombre del socio que tiene el libro. Si el libro está en la biblioteca,
     * lanza LibroNoPrestadoException.
     */
    public String quienTieneElLibro(Libro p_libro) throws LibroNoPrestadoException {
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException("El libro se encuentra en la biblioteca");
        }
        return ultimoPrestamoDe(p_libro).getSocio().getNombre();
    }

    /**
     * Devuelve el socio con el DNI indicado, o null si no existe.
     */
    public Socio buscarSocio(int p_dni) {
        for (Socio socio : socios) {
            if (socio.getDniSocio() == p_dni) {
                return socio;
            }
        }
        return null;
    }

    /**
     * Devuelve el primer libro con el título indicado, o null si no existe.
     * (Auxiliar para GestionBiblioteca.)
     */
    public Libro buscarLibro(String p_titulo) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equals(p_titulo)) {
                return libro;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Listados
    // ------------------------------------------------------------------

    /**
     * Formato1: listado de socios.
     */
    public String listaDeSocios() {
        String lista = "Lista de Socios: \n\n";
        int numero = 1;
        for (Socio socio : socios) {
            lista += numero + ") " + socio.toString() + "\n";
            numero++;
        }
        lista += "**************************************\n";
        lista += "Cantidad de Socios del tipo Estudiante: "
                + cantidadDeSociosPorTipo("Estudiante") + "\n";
        lista += "Cantidad de Socios del tipo Docente: "
                + cantidadDeSociosPorTipo("Docente") + "\n";
        lista += "**************************************\n";
        return lista;
    }

    /**
     * Formato2: listado de libros.
     */
    public String listaDeLibros() {
        String lista = "Lista de Libros: \n\n";
        int numero = 1;
        for (Libro libro : libros) {
            lista += numero + ") " + libro.toString() + " || Prestado: ("
                    + (libro.prestado() ? "Si" : "No") + ")\n";
            numero++;
        }
        return lista;
    }

    /**
     * Lista de títulos de la biblioteca, sin repetir (puede haber más de un ejemplar).
     */
    public String listaDeTitulos() {
        ArrayList<String> titulos = new ArrayList<String>();
        for (Libro libro : libros) {
            if (!titulos.contains(libro.getTitulo())) {
                titulos.add(libro.getTitulo());
            }
        }
        String lista = "Lista de Titulos: \n\n";
        int numero = 1;
        for (String titulo : titulos) {
            lista += numero + ") " + titulo + "\n";
            numero++;
        }
        return lista;
    }

    /**
     * Formato3: listado de docentes responsables.
     */
    public String listaDeDocentesResponsables() {
        String lista = "Lista de Docentes Responsables: \n\n";
        for (Docente docente : docentesResponsables()) {
            lista += "* " + docente.toString() + "\n";
        }
        return lista;
    }
}
