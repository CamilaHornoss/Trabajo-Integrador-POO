import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Prueba rápida de Biblioteca usando las clases de +libs/GT_4.jar.
 * (No reemplaza a GestionBiblioteca, que deben hacer entre todos.)
 */
public class PruebaBiblioteca {

    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Biblioteca Central");

        b.nuevoSocioDocente(14524782, "Juan Perez", "Matematica");
        b.nuevoSocioDocente(17982110, "Juan Fernandez", "Fisica");
        b.nuevoSocioEstudiante(28987498, "Francisco Paenza", "Sistemas");
        b.nuevoSocioEstudiante(31987123, "Cesar Milstein", "Quimica");

        b.nuevoLibro("JAVA. Como Programar", 1, "Pearson", 2010);
        b.nuevoLibro("Programando con JAVA", 2, "Anaya", 2012);
        b.nuevoLibro("Programando con JAVA", 2, "Anaya", 2012);
        b.nuevoLibro("Vivir para contarla", 1, "Sudamericana", 2002);

        Socio juan = b.buscarSocio(14524782);
        Socio paenza = b.buscarSocio(28987498);
        Libro java = b.buscarLibro("JAVA. Como Programar");
        Libro prog = b.buscarLibro("Programando con JAVA");

        // Retiro viejo (queda vencido) y retiro de hoy
        Calendar viejo = new GregorianCalendar(2014, Calendar.OCTOBER, 15);
        System.out.println("Prestar JAVA a Juan (retiro viejo): "
                + b.prestarLibro(viejo, juan, java));
        System.out.println("Prestar Programando a Paenza (hoy): "
                + b.prestarLibro(new GregorianCalendar(), paenza, prog));

        System.out.println();
        System.out.println(b.listaDeSocios());
        System.out.println(b.listaDeLibros());
        System.out.println(b.listaDeTitulos());
        System.out.println(b.listaDeDocentesResponsables());
        System.out.println("Cantidad de estudiantes: " + b.cantidadDeSociosPorTipo("Estudiante"));
        System.out.println("Prestamos vencidos: " + b.prestamosVencidos().size());

        try {
            System.out.println("Tiene Programando con JAVA: " + b.quienTieneElLibro(prog));
            b.devolverLibro(prog);
            b.devolverLibro(prog); // segunda vez: debe lanzar la excepcion
        } catch (LibroNoPrestadoException e) {
            System.out.println("Excepcion: " + e.getMessage());
        }
    }
}
